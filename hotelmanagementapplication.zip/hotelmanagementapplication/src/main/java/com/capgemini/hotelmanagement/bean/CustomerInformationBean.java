package com.capgemini.hotelmanagement.bean;

public class CustomerInformationBean {

	private String UserName;
	private String Name;
	private long PhoneNumber;
	private String MailId;
	private String password;

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public long getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getMailId() {
		return MailId;
	}

	public void setMailId(String mailId) {
		MailId = mailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((MailId == null) ? 0 : MailId.hashCode());
		result = prime * result + ((Name == null) ? 0 : Name.hashCode());
		result = prime * result + (int) (PhoneNumber ^ (PhoneNumber >>> 32));
		result = prime * result + ((UserName == null) ? 0 : UserName.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerInformationBean other = (CustomerInformationBean) obj;
		if (MailId == null) {
			if (other.MailId != null)
				return false;
		} else if (!MailId.equals(other.MailId))
			return false;
		if (Name == null) {
			if (other.Name != null)
				return false;
		} else if (!Name.equals(other.Name))
			return false;
		if (PhoneNumber != other.PhoneNumber)
			return false;
		if (UserName == null) {
			if (other.UserName != null)
				return false;
		} else if (!UserName.equals(other.UserName))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CustomerInformation [UserName=" + UserName + ", Name=" + Name + ", PhoneNumber=" + PhoneNumber
				+ ", MailId=" + MailId + ", password=" + password + "]";
	}

}
