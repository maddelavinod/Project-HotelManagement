package com.capgemini.hotelmanagement.exception;

@SuppressWarnings("serial")
public class UserNameNotFoundException extends RuntimeException {

	String message = "Please Enter correct username ";

	public String requriedmessage() {
		return message;

	}

}
