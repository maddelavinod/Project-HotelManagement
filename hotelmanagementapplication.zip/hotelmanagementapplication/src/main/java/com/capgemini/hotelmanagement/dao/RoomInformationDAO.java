package com.capgemini.hotelmanagement.dao;

import java.util.List;

import com.capgemini.hotelmanagement.bean.RoomInformationBean;

public interface RoomInformationDAO {

	public boolean roomAvailability(String hotelname, String location);

	public boolean operaterooms();

	public boolean addrooms(RoomInformationBean roomift);

	public boolean deleteroom();

	public boolean updateroom(RoomInformationBean roominof);
	
	public List<RoomInformationBean> getAllRooms();

}
