package com.capgemini.hotelmanagement.dao;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.EmployeeInformationBean;
import com.capgemini.hotelmanagement.exception.DetailsNotFoundException;
import com.capgemini.hotelmanagement.exception.EmployeeNotFoundException;
import com.capgemini.hotelmanagement.exception.RegistrationFailedException;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class EmployeeDAOImpl implements EmployeeDAO {
	InputValidation inputvalidation = Factory.getInputValidationInstance();
	CustomerDAO customerimpl = Factory.getCustomerDAOInstance();
	static final Logger log = Logger.getLogger(EmployeeDAOImpl.class);
	Scanner sc = new Scanner(System.in);
	int size = 0;
	int count = 0;
	EmployeeInformationBean employeeinfo = Factory.getEmployeeInformationBeanInstance();
	static List<EmployeeInformationBean> employeelist = new ArrayList<EmployeeInformationBean>();
	static {
		EmployeeInformationBean employeeinfo = Factory.getEmployeeInformationBeanInstance();
		employeeinfo.setUsername("chandra");
		employeeinfo.setName("Chandra Maddela");
		employeeinfo.setPhonenumber(7386765135l);
		employeeinfo.setMailid("chandra@gmail.com");
		employeeinfo.setPassword("Chandra@123");
		employeeinfo.setSalary(15000);

		employeelist.add(employeeinfo);

	}

	@Override
	public boolean employeelogin() {
		log.info("Enter your user name");
		String username = sc.nextLine();
		log.info("Enter your password");
		String Password = sc.nextLine();
		int count = 0;
		for (EmployeeInformationBean employeeinfo : employeelist) {
			if (employeeinfo.getUsername().equals(username) && employeeinfo.getPassword().equals(Password)) {
				count++;

			}
		}
		if (count == 1) {
			log.info("Login Successsful");
			employee();

			return true;

		} else {
			log.info("login details not found  forgot password please contact admin");
		}

		return false;
	}

	@Override
	public boolean operateemployee() {

		log.info("Please Select the operation of Employee");
		log.info("1.addemployee");
		log.info("2.delete employee");
		log.info("3.update employee");
		log.info("4.back");
		String anyt = sc.nextLine();
		while (!inputvalidation.choiceValidate1(anyt)) {
			log.info("Please Enter valid choice");
			anyt = sc.nextLine();
		}
		int valu = Integer.parseInt(anyt);
		D: switch (valu) {
		case 1:
			EmployeeInformationBean empl = Factory.getEmployeeInformationBeanInstance();
			AddEmployee(empl);

			break;
		case 2:
			deleteemployee();

			break;
		case 3:
			EmployeeInformationBean emplls = Factory.getEmployeeInformationBeanInstance();
			updateemployee(emplls);
			break;
		case 4:
			break D;
		}

		return true;
	}

	@Override
	public boolean AddEmployee(EmployeeInformationBean employee) {
		ArrayList<EmployeeInformationBean> empl = new ArrayList<EmployeeInformationBean>();
		EmployeeInformationBean empee = Factory.getEmployeeInformationBeanInstance();
		log.info("Please Enter Employee Details to Add Employee");

		log.info("Please Enter  username ");
		String usname = sc.nextLine();
		for (EmployeeInformationBean eme : employeelist) {
			while (eme.getUsername().equals(usname)) {
				log.info("username exits");
				log.info(
						"Please Enter  username (It can contains characters and numbers and special characters'-','_',but length must be 3-14)");
				usname = sc.nextLine();

			}
		}
		while (!inputvalidation.usernameValidation(usname)) {
			log.info(
					"Please Enter Valid userName(It can contains characters and numbers and special characters'-','_',but length must be 3-14) ");
			usname = sc.nextLine();
		}

		log.info("Please Enter Name like First-name and Last-name ");
		String ename = sc.nextLine();
		while (!inputvalidation.nameValidation(ename)) {
			log.info("Please Enter Valid Name Like First name and Last Name");
			ename = sc.nextLine();
		}
		log.info("Please Enter Phone number  must contains 10 digits and starts with 6 or 7 or 8 or 9");
		String pnumber = sc.nextLine();
		while (!inputvalidation.phonenumberValidation(pnumber)) {
			log.info("Please Enter Valid Phone Number  must contains 10 digits and starts with 6 or 7 or 8 or 9");
			pnumber = sc.nextLine();
		}
		long phonenumber = Long.parseLong(pnumber);

		log.info("Please Enter MailId like abc@abc.abc");
		String email = sc.nextLine();
		for (EmployeeInformationBean emelt : employeelist) {
			while (emelt.getMailid().equals(email)) {
				log.info("mailid exists");
				log.info("Please Enter MailId like abc@abc.abc");
				email = sc.nextLine();

			}
		}
		while (!inputvalidation.mailValidation(email)) {
			log.info("Please Enter Valid mail id like abc@abc.abc");
			email = sc.nextLine();
		}
		log.info("Please Enter Your Password must contain one uppercase,one lower case,numbers and special characters");
		String password = sc.nextLine();
		while (!inputvalidation.passwordValidation(password)) {
			log.info(
					"Please Enter Valid Password must contain one uppercase,one lower case,numbers and special characters");
			password = sc.nextLine();
		}
		log.info("Please Enter Salary only numbers");
		String sala = sc.nextLine();
		while (!inputvalidation.salaryValidation(sala)) {
			log.info("Please Enter Valid  salary only numbers");
			sala = sc.nextLine();
		}
		int salary = Integer.parseInt(sala);

		empee.setUsername(usname);
		empee.setName(ename);
		empee.setMailid(email);
		empee.setPhonenumber(phonenumber);
		empee.setPassword(password);
		empee.setSalary(salary);
		empl.add(empee);
		employeelist.addAll(empl);
		try {
			if (size == employeelist.size()) {
				throw new RegistrationFailedException();
			} else {
				log.info("Registration is sucessfull");
			}
		} catch (RegistrationFailedException e) {
			log.error(e.getDetails());
			return false;
		}

		return true;
	}

	@Override
	public boolean deleteemployee() {
		log.info("Please Enter user name");
		String usernam = sc.nextLine();
		Iterator<EmployeeInformationBean> employeeBean = employeelist.iterator();
		while (employeeBean.hasNext()) {

			EmployeeInformationBean str = employeeBean.next();
			if (str.getUsername().equals(usernam)) {
				count++;

				log.info("username found");
				employeeBean.remove();
				log.info("Data Deleted Sucessfully");

			}
		}
		try {
			if (count == 0) {
				throw new DetailsNotFoundException();
			}
		} catch (DetailsNotFoundException e) {
			log.error(e.getExceptionMessage());
			return false;
		}
		return true;
	}

	@Override
	public boolean updateemployee(EmployeeInformationBean employeein3f) {

		log.info("Please Enter Your Username");
		String usernam1 = sc.nextLine();
		for (EmployeeInformationBean employeeibean : employeelist) {
			if (employeeibean.getUsername().equals(usernam1)) {
				count++;
				log.info("Request is Done ");
				log.info(" ============= update details ==============");

				log.info("Please Enter Name  like First-name and Last-name ");
				String ename = sc.nextLine();
				while (!inputvalidation.nameValidation(ename)) {
					log.info("Please Enter Valid Name Like First name and Last Name");
					ename = sc.nextLine();
				}
				log.info("Please Enter Phone number  must contains 10 digits and starts with 6 or 7 or 8 or 9");
				String pnumber = sc.nextLine();
				while (!inputvalidation.phonenumberValidation(pnumber)) {
					log.info(
							"Please Enter Valid Phone Number  must contains 10 digits and starts with 6 or 7 or 8 or 9");
					pnumber = sc.nextLine();
				}
				long phonenumber = Long.parseLong(pnumber);

				log.info("Please Enter MailId like abc@abc.abd");
				String email = sc.nextLine();

				while (!inputvalidation.mailValidation(email)) {
					log.info("Please Enter Valid mail id like abc@abc.abd");
					email = sc.nextLine();
				}
				log.info(
						"Please Enter Your Password must contain one uppercase,one lower case,numbers and special characters");
				String password = sc.nextLine();
				while (!inputvalidation.passwordValidation(password)) {
					log.info(
							"Please Enter Valid Password must contain one uppercase,one lower case,numbers and special characters");
					password = sc.nextLine();
				}
				log.info("Please Enter Salary must be only numbers");
				String sala = sc.nextLine();
				while (!inputvalidation.salaryValidation(sala)) {
					log.info("Please Enter Valid  salary must be only numbers");
					sala = sc.nextLine();
				}
				int salary = Integer.parseInt(sala);

				employeeibean.setUsername(usernam1);
				employeeibean.setName(ename);
				employeeibean.setMailid(email);
				employeeibean.setPhonenumber(phonenumber);
				employeeibean.setPassword(password);
				employeeibean.setSalary(salary);

			}
		}
		try {
			if (count == 0) {
				throw new DetailsNotFoundException();
			} else {
				log.info("Data Updated sucessfully");
			}
		} catch (DetailsNotFoundException f) {
			log.info(f.getExceptionMessage());
			return false;
		}
		return true;
	}

	@Override
	public List<EmployeeInformationBean> getAllemployees() {
		log.info("*****Get All Employees*****");
		for (EmployeeInformationBean customerinfo : employeelist) {
			try {
				if (employeelist.isEmpty()) {
					throw new EmployeeNotFoundException();
				} else {
					log.info(customerinfo);
				}
			} catch (EmployeeNotFoundException e) {
				log.error(e.getMessage());
			}
		}
		return employeelist;
	}

	@Override
	public boolean employee() {
		K: do {
			log.info("Please select your operation");
			log.info("1.Booking Hotel");
			log.info("2.customer details");
			log.info("3.logout");
			String next = sc.nextLine();
			while (!inputvalidation.choiceValidate2(next)) {
				log.info("Enter valid choice");
				next = sc.nextLine();
			}
			int opt = Integer.parseInt(next);
			switch (opt) {
			case 1:
				customerimpl.hotelbooking();
				break;
			case 2:
				customerimpl.getAllCustomers();
				break;
			case 3:
				break K;

			}
		} while (true);

		return true;
	}

}
