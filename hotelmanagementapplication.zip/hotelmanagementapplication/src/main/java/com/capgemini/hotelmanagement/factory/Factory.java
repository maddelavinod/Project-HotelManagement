package com.capgemini.hotelmanagement.factory;

import com.capgemini.hotelmanagement.bean.AdminInformationBean;
import com.capgemini.hotelmanagement.bean.BookingInformationBean;
import com.capgemini.hotelmanagement.bean.CustomerInformationBean;
import com.capgemini.hotelmanagement.bean.EmployeeInformationBean;
import com.capgemini.hotelmanagement.bean.HotelInformationBean;
import com.capgemini.hotelmanagement.bean.RoomInformationBean;
import com.capgemini.hotelmanagement.dao.AdminDAO;
import com.capgemini.hotelmanagement.dao.AdminDAOImpl;
import com.capgemini.hotelmanagement.dao.BookingInformationDAO;
import com.capgemini.hotelmanagement.dao.BookingInformationDAOImpl;
import com.capgemini.hotelmanagement.dao.CustomerDAO;
import com.capgemini.hotelmanagement.dao.CustomerDAOImpl;
import com.capgemini.hotelmanagement.dao.EmployeeDAO;
import com.capgemini.hotelmanagement.dao.EmployeeDAOImpl;
import com.capgemini.hotelmanagement.dao.HotelInformationDAO;
import com.capgemini.hotelmanagement.dao.HotelInformationDAOImpl;
import com.capgemini.hotelmanagement.dao.RoomInformationDAO;
import com.capgemini.hotelmanagement.dao.RoomInformationDAOImpl;
import com.capgemini.hotelmanagement.service.AdminService;
import com.capgemini.hotelmanagement.service.AdminServiceImpl;
import com.capgemini.hotelmanagement.service.CustomerService;
import com.capgemini.hotelmanagement.service.CustomerServiceImpl;
import com.capgemini.hotelmanagement.service.EmployeeService;
import com.capgemini.hotelmanagement.service.EmployeeServiceImpl;
import com.capgemini.hotelmanagement.validation.InputValidation;
import com.capgemini.hotelmanagement.validation.InputValidationImpl;

public class Factory {

	private Factory() {

	}

	public static AdminInformationBean getAdminLoginInstance() {
		AdminInformationBean adminlogin = new AdminInformationBean();
		return adminlogin;

	}

	public static CustomerInformationBean getCustomerInformationInstance() {
		CustomerInformationBean customerregistration = new CustomerInformationBean();
		return customerregistration;
	}

	public static InputValidation getInputValidationInstance() {
		return new InputValidationImpl();
	}

	public static CustomerService getCustomerServiceInstance() {

		CustomerService customerservice = new CustomerServiceImpl();
		return customerservice;

	}

	public static CustomerDAO getCustomerDAOInstance() {

		CustomerDAO customerdao = new CustomerDAOImpl();
		return customerdao;
	}

	public static AdminDAO getAdminDAOInstance() {
		AdminDAO admindao = new AdminDAOImpl();
		return admindao;

	}

	public static HotelInformationBean getHotelInformationInstance() {

		HotelInformationBean hotelregistration = new HotelInformationBean();
		return hotelregistration;
	}

	public static AdminService getAdminServiceInstance() {
		AdminService adminservice = new AdminServiceImpl();
		return adminservice;
	}

	public static RoomInformationBean getRoomInformationInstance() {
		RoomInformationBean roomregistration = new RoomInformationBean();
		return roomregistration;
	}

	public static HotelInformationDAO getHotelInformationDAOInstance() {
		HotelInformationDAO hotelinfo = new HotelInformationDAOImpl();
		return hotelinfo;
	}

	public static RoomInformationDAO getRoomInformationDAOInstance() {
		RoomInformationDAO roominfo = new RoomInformationDAOImpl();
		return roominfo;

	}

	public static BookingInformationDAO getBookingInformationDAOInstance() {
		BookingInformationDAO bookinginfo = new BookingInformationDAOImpl();
		return bookinginfo;

	}

	public static BookingInformationBean getBookingInformationBeanInstance() {
		BookingInformationBean bookinginformation = new BookingInformationBean();
		return bookinginformation;

	}

	public static EmployeeInformationBean getEmployeeInformationBeanInstance() {
		EmployeeInformationBean employeeinfo = new EmployeeInformationBean();
		return employeeinfo;

	}

	public static EmployeeService getEmployeeServiceInstance() {
		EmployeeService employeeservice = new EmployeeServiceImpl();
		return employeeservice;
	}
	public static EmployeeDAO getEmployeeDAOInstance() {
		EmployeeDAO employeedao=new EmployeeDAOImpl();
		return employeedao;
		
	}

	

}
