package com.capgemini.hotelmanagement.exception;

@SuppressWarnings("serial")
public class HotelNotfoundException extends RuntimeException {
	String message = "Hotel not present ";

	public String getExceptionMessage() {
		return message;

	}

}
