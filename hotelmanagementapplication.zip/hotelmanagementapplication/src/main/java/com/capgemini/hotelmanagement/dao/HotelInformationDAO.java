package com.capgemini.hotelmanagement.dao;

import java.util.List;

import com.capgemini.hotelmanagement.bean.HotelInformationBean;

public interface HotelInformationDAO {

	public boolean AddHotel(HotelInformationBean hotel);

	public boolean GetHotel(String location);

	public boolean operatehotels();

	public boolean deletehotel();

	public boolean updatehotel(HotelInformationBean hotelinof);

	public List<HotelInformationBean> getAllhotels();
	
	

}
