package com.capgemini.hotelmanagement.exception;

@SuppressWarnings("serial")
public class CustomerNotFoundException extends RuntimeException {
	String message = "No Details present ";

	public String getMessage() {
		return message;

	}

}
