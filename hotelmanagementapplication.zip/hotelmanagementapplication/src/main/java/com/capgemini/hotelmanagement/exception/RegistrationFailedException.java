package com.capgemini.hotelmanagement.exception;

@SuppressWarnings("serial")
public class RegistrationFailedException extends RuntimeException {

	String notice = " Registration is not sucessfull ";

	public String getDetails() {
		return notice;
	}

}
