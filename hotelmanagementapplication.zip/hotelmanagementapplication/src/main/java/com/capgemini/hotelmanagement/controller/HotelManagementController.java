package com.capgemini.hotelmanagement.controller;

import java.util.Scanner;


import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.service.AdminService;
import com.capgemini.hotelmanagement.service.CustomerService;
import com.capgemini.hotelmanagement.service.EmployeeService;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class HotelManagementController {

	static final Logger log = Logger.getLogger(HotelManagementController.class);

	public static void main(String[] args) {

		log.info("Welcome to Hotel Management Application");

		log.info("================================");

		log.info("Please tell me who are you");

		InputValidation inputValidations = Factory.getInputValidationInstance();

		L: do {
			log.info("1.Customer");
			log.info("2.Employee");
			log.info("3.Admin");
			log.info("4.Exit");

			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			String choice1 = sc.next();
			while (!inputValidations.choiceValidate1(choice1)) {
				log.info(" enter valid choice");
				choice1 = sc.next();
			}
			int choice = Integer.parseInt(choice1);

			switch (choice) {

			case 1:
				CustomerService customerservice = Factory.getCustomerServiceInstance();
				customerservice.Customer();

				break;
			case 2:
				EmployeeService employeeservice = Factory.getEmployeeServiceInstance();
				employeeservice.employee();

				break;
			case 3:
				AdminService adminservice = Factory.getAdminServiceInstance();
				try {
					adminservice.Hotel();
				} catch (Exception e) {

					System.err.println("File not found");
				}

				break;
			case 4:

				break L;

			}
		} while (true);
		log.info("Thanks For Visting");

	}

}
