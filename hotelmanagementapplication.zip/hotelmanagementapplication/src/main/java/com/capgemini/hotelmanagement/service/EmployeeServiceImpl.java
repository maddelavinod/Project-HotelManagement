package com.capgemini.hotelmanagement.service;

import java.util.Scanner;


import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.dao.EmployeeDAO;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDAO employeedao = Factory.getEmployeeDAOInstance();

	static final Logger log = Logger.getLogger(EmployeeServiceImpl.class);
	InputValidation inputvalidation = Factory.getInputValidationInstance();
	Scanner sc = new Scanner(System.in);

	@Override
	public boolean employee() {

		log.info("*********Welcome To Employee Module************");

		B: do {
			log.info("1.login");
			log.info("2.back");

			log.info("Please enter your choice");
			String ch = sc.nextLine();
			while (!inputvalidation.choiceValidate3(ch)) {
				log.info("Please enter valid choice");
				ch = sc.nextLine();
			}
			int cho = Integer.parseInt(ch);
			switch (cho) {
			case 1:
				employeedao.employeelogin();
				break;
			case 2:
				break B;
			}

		} while (true);
		return true;
	}

}
