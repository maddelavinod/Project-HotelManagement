package com.capgemini.hotelmanagement.dao;

import java.util.List;

import com.capgemini.hotelmanagement.bean.EmployeeInformationBean;

public interface EmployeeDAO {

	public boolean employeelogin();

	public boolean operateemployee();

	public boolean AddEmployee(EmployeeInformationBean employee);

	public boolean deleteemployee();

	public boolean updateemployee(EmployeeInformationBean employeein3f);

	public List<EmployeeInformationBean> getAllemployees();
	
	public boolean employee();

}
