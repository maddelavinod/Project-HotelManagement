package com.capgemini.hotelmanagement.dao;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.HotelInformationBean;
import com.capgemini.hotelmanagement.exception.DetailsNotFoundException;
import com.capgemini.hotelmanagement.exception.EmployeeNotFoundException;
import com.capgemini.hotelmanagement.exception.HotelNotfoundException;
import com.capgemini.hotelmanagement.exception.RegistrationFailedException;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class HotelInformationDAOImpl implements HotelInformationDAO {

	static final Logger log = Logger.getLogger(HotelInformationDAOImpl.class);
	Scanner sc = new Scanner(System.in);
	InputValidation inputvalidation = Factory.getInputValidationInstance();
	static List<HotelInformationBean> hotellist = new ArrayList<HotelInformationBean>();
	HotelInformationBean hotelinfo = Factory.getHotelInformationInstance();
	int size = 0;
	int count = 0;

	static {
		HotelInformationBean hotelinformation = Factory.getHotelInformationInstance();
		hotelinformation.setHotelNumber("1");
		hotelinformation.setHotelName("Royal Palace");
		hotelinformation.setLocation("banglore");
		hotelinformation.setMailid("Royalpalace@gmail.com");
		hotelinformation.setPhonenumber(9999955555l);

		HotelInformationBean hotelinformation1 = Factory.getHotelInformationInstance();
		hotelinformation1.setHotelNumber("2");
		hotelinformation1.setHotelName("Green View");
		hotelinformation1.setLocation("banglore");
		hotelinformation1.setMailid("greenview@gmail.com");
		hotelinformation1.setPhonenumber(9569955555l);

		HotelInformationBean hotelinformation3 = Factory.getHotelInformationInstance();
		hotelinformation3.setHotelNumber("1");
		hotelinformation3.setHotelName("Grand Chola");
		hotelinformation3.setLocation("hyderabad");
		hotelinformation3.setMailid("Grandchola@gamil.com");
		hotelinformation3.setPhonenumber(7878784554l);

		HotelInformationBean hotelinformation4 = Factory.getHotelInformationInstance();
		hotelinformation4.setHotelNumber("2");
		hotelinformation4.setHotelName("Hotel Palasa");
		hotelinformation4.setLocation("hyderabad");
		hotelinformation4.setMailid("palasa@gamil.com");
		hotelinformation4.setPhonenumber(9856784554l);

		hotellist.add(hotelinformation);
		hotellist.add(hotelinformation1);
		hotellist.add(hotelinformation3);
		hotellist.add(hotelinformation4);

	}

	@Override
	public boolean AddHotel(HotelInformationBean hotel) {
		String loc1 = "hyderabad";
		String loc2 = "banglore";

		ArrayList<HotelInformationBean> hoteladd = new ArrayList<HotelInformationBean>();
		log.info("Enter details to add hotel");

		log.info("Please enter Hotel Location");
		String location = sc.nextLine();

		while (!(loc1.equals(location) || loc2.equals(location))) {
			log.info("please enter location as'hyderabad' or'banglore'");
			location = sc.nextLine();

		}

		while (!inputvalidation.locationValidation(location)) {
			log.info("Please enter valid location");
			location = sc.nextLine();
		}

		log.info("Please enter hotel number");
		String hotelnum = sc.nextLine();
		for (HotelInformationBean hotelingx : hotellist) {
			while (loc1.equals(location) && hotelingx.getHotelNumber().equals(hotelnum)
					|| loc2.equals(location) && hotelingx.getHotelNumber().equals(hotelnum)) {
				log.info("Hotel number Already exists");
				log.info("Enter new hotel number");
				hotelnum = sc.nextLine();

			}
		}

		while (!inputvalidation.hotelnumberValidation(hotelnum)) {
			log.info("Please enter number");
			hotelnum = sc.nextLine();
		}

		log.info("Please Enter Hotel Name");
		String hotelname = sc.nextLine();
		while (!inputvalidation.nameValidation(hotelname)) {
			log.info("Please enter valid name like Hotel Palasa");
			hotelname = sc.nextLine();
		}

		log.info("Please enter mailid");
		String mail = sc.nextLine();
		while (!inputvalidation.mailValidation(mail)) {
			log.info("Please enter valid mailid");
			mail = sc.nextLine();
		}

		log.info("Please enter Phone number");
		String number = sc.nextLine();
		while (!inputvalidation.phonenumberValidation(number)) {
			log.info("Please enter valid phone number");
			number = sc.nextLine();
		}
		long phonenumber = Long.parseLong(number);

		hotelinfo.setHotelNumber(hotelnum);
		hotelinfo.setHotelName(hotelname);
		hotelinfo.setLocation(location);
		hotelinfo.setMailid(mail);
		hotelinfo.setPhonenumber(phonenumber);

		hoteladd.add(hotelinfo);
		hotellist.addAll(hoteladd);
		try {
			if (size == hotellist.size()) {
				log.info("Registration is not sucessfull ");
			} else {
				log.info("Registration is sucessfull");
			}
		} catch (RegistrationFailedException e) {
			log.error(e.getDetails());
		}

		return true;
	}

	@Override
	public boolean GetHotel(String location) {
		RoomInformationDAO roominfo = Factory.getRoomInformationDAOInstance();

		log.info("Please select Hotel");

		int count1 = 0;

		for (HotelInformationBean hotelinfobean : hotellist) {
			if (hotelinfobean.getLocation().equals(location)) {
				log.info(hotelinfobean.getHotelNumber() + "----" + hotelinfobean.getHotelName());
				count++;
			}

		}
		log.info("*********Enter Hotel Number*******");
		String cc = sc.nextLine();
		for (HotelInformationBean hotelinfobean : hotellist) {
			if (hotelinfobean.getHotelNumber().equals(cc) && hotelinfobean.getLocation().equals(location)) {
				count1++;
				roominfo.roomAvailability(cc, location);

			}
		}

		try {
			if (count1 == 0) {
				throw new HotelNotfoundException();
			}
		} catch (HotelNotfoundException x) {
			log.info(x.getExceptionMessage());
			return false;
		}

		return true;
	}

	@Override
	public boolean operatehotels() {

		log.info("Please Select the operation of hotel");
		log.info("1.addhotels");
		log.info("2.delete hotels");
		log.info("3.update hotels");
		log.info("4.back");
		String any = sc.nextLine();
		while (!inputvalidation.choiceValidate1(any)) {
			log.info("Please Enter valid choice");
			any = sc.nextLine();
		}
		int val = Integer.parseInt(any);
		D: switch (val) {
		case 1:
			AddHotel(new HotelInformationBean());
			break;
		case 2:
			deletehotel();
			break;
		case 3:
			HotelInformationBean hotelin = Factory.getHotelInformationInstance();
			updatehotel(hotelin);
			break;
		case 4:
			break D;
		}

		return true;

	}

	@Override
	public boolean deletehotel() {

		log.info("Please enter hotel number");
		String hotelnumb = sc.nextLine();
		while (!inputvalidation.hotelnumberValidation(hotelnumb)) {
			log.info("Please enter number");
			hotelnumb = sc.nextLine();
		}
		log.info("Please enter Hotel Location");
		String location2 = sc.nextLine();
		while (!inputvalidation.locationValidation(location2)) {
			log.info("Please enter valid location");
			location2 = sc.nextLine();
		}

		Iterator<HotelInformationBean> hotelbean = hotellist.iterator();
		while (hotelbean.hasNext()) {

			HotelInformationBean str = hotelbean.next();
			if (str.getHotelNumber().equals(hotelnumb) && str.getLocation().equals(location2)) {
				count++;

				log.info("Hotel found");
				hotelbean.remove();

			}

		}
		try {
			if (count == 0) {
				throw new DetailsNotFoundException();

			} else {
				log.info("Data Deleted sucessfull");
			}
		} catch (DetailsNotFoundException d) {
			log.info(d.getExceptionMessage());
			return false;
		}

		return true;
	}

	@Override
	public boolean updatehotel(HotelInformationBean hotelinof) {

		log.info("Please enter hotel number");
		String hotelnmb = sc.nextLine();
		while (!inputvalidation.hotelnumberValidation(hotelnmb)) {
			log.info("Please enter number");
			hotelnmb = sc.nextLine();
		}

		log.info("Please enter Hotel Location");
		String location1 = sc.nextLine();
		while (!inputvalidation.locationValidation(location1)) {
			log.info("Please enter valid location");
			location1 = sc.nextLine();
		}

		for (HotelInformationBean hotelinf : hotellist) {

			if (hotelinf.getHotelNumber().equals(hotelnmb) && hotelinf.getLocation().equals(location1)) {
				count++;
				log.info("Request is Done ");
				log.info(" ============= update details ==============");

				log.info("Please Enter Hotel Name");
				String hotelname = sc.nextLine();
				while (!inputvalidation.nameValidation(hotelname)) {
					log.info("Please enter valid name like Hotel Palasa");
					hotelname = sc.nextLine();
				}

				log.info("Please enter mailid");
				String mail = sc.nextLine();
				while (!inputvalidation.mailValidation(mail)) {
					log.info("Please enter valid mailid");
					mail = sc.nextLine();
				}

				log.info("Please enter Phone number");
				String number = sc.nextLine();
				while (!inputvalidation.phonenumberValidation(number)) {
					log.info("Please enter valid phone number");
					number = sc.nextLine();
				}
				long phonenumber = Long.parseLong(number);

				hotelinf.setHotelNumber(hotelnmb);
				hotelinf.setHotelName(hotelname);
				hotelinf.setLocation(location1);
				hotelinf.setMailid(mail);
				hotelinf.setPhonenumber(phonenumber);

				log.info("Data Updated sucessfully");
			}

		}
		try {
			if (count == 0) {
				throw new DetailsNotFoundException();
			}
		} catch (DetailsNotFoundException f) {
			log.info(f.getExceptionMessage());
			return false;
		}

		return true;
	}

	@Override
	public List<HotelInformationBean> getAllhotels() {
		log.info("*****Hotel Details*****");
		for (HotelInformationBean customerinfo : hotellist) {
			try {
				if (hotellist.isEmpty()) {
					throw new EmployeeNotFoundException();
				} else {
					log.info(customerinfo);
				}
			} catch (EmployeeNotFoundException e) {
				log.error(e.getMessage());
			}
		}
		return hotellist;
	}

}
