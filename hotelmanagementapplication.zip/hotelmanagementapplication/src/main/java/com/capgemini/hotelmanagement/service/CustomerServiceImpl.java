package com.capgemini.hotelmanagement.service;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.CustomerInformationBean;
import com.capgemini.hotelmanagement.dao.CustomerDAO;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class CustomerServiceImpl implements CustomerService {
	
	CustomerInformationBean customerinform = Factory.getCustomerInformationInstance();

	static final Logger log = Logger.getLogger(CustomerServiceImpl.class);
	Scanner sc = new Scanner(System.in);
	InputValidation inputvalidation = Factory.getInputValidationInstance();
	CustomerDAO customerdao = Factory.getCustomerDAOInstance();

	@Override
	public boolean Customer() {

		log.info("Welcome TO  Customer Module");

		L: do {
			log.info("1.Login(*If you are an existing coustmer* )");
			log.info("2.Register(*If you are new coustmer)");
			log.info("3.Forgot password");
			log.info("4.Exit to Home Page");

			String access = sc.next();
			while (!inputvalidation.choiceValidate1(access)) {
				System.out.println(" enter valid choice");
				access = sc.next();
			}
			int choice = Integer.parseInt(access);

			switch (choice) {

			case 1:

				customerdao.customerlogin();

				break;

			case 2:

				customerdao.customerregistration(customerinform);

				break;
			case 3:
				customerdao.updatecustomer();
				break;
			case 4:
				break L;
			}
		} while (true);
		return true;
	}

}
