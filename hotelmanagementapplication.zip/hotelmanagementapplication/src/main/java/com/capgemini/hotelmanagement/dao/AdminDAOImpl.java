package com.capgemini.hotelmanagement.dao;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.ArrayList;

import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.AdminInformationBean;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class AdminDAOImpl implements AdminDAO {
	Properties p = new Properties();
	static final Logger log = Logger.getLogger(AdminDAOImpl.class);
	Scanner sc = new Scanner(System.in);
	static List<AdminInformationBean> admin = new ArrayList<AdminInformationBean>();
	InputValidation inputvalidation = Factory.getInputValidationInstance();
	static {
		AdminInformationBean admininfo1 = Factory.getAdminLoginInstance();
		admininfo1.setUsername("admin");
		admininfo1.setPassword("Admin@123");
		admin.add(admininfo1);
	}

	@Override
	public boolean AdminLogin() throws IOException {

		FileInputStream fis = new FileInputStream("db.properties");
		p.load(fis);

		log.info("Enter your username");
		String userNm = sc.nextLine();
		log.info("Enter your password");
		String passwordUser = sc.nextLine();

		int count = 0;

		if (p.getProperty("username").equals(userNm) && p.getProperty("password").equals(passwordUser)) {
			count++;

		}

		if (count == 1) {

			log.info("Login sucessfull");
			operateadmin();

		} else {
			log.info("Login failed Please try again");
			return false;
		}

		return true;
	}

	@Override
	public boolean operateadmin() {
		A: do {
			log.info("Please select which operation you need to access");
			log.info("1.operation on Hotels");
			log.info("2.Operation on Rooms");
			log.info("3.Operation on Employees");
			log.info("4.View List Of Hotels");
			log.info("5.Get All Employees");
			log.info("6.View Booking of Specified Hotels");
			log.info("7.View Guest List of Specified Hotels");
			log.info("8.View Booking At Specified Date");
			log.info("9.logout");
			String valid = sc.nextLine();
			while (!inputvalidation.choiceValidation4(valid)) {
				log.info("Please enter valid choice");
				valid = sc.nextLine();
			}
			int act = Integer.parseInt(valid);
			switch (act) {
			case 1:
				HotelInformationDAO hotelinfor = Factory.getHotelInformationDAOInstance();
				hotelinfor.operatehotels();
				break;
			case 2:
				RoomInformationDAO roominr = Factory.getRoomInformationDAOInstance();
				roominr.operaterooms();
				break;
			case 3:
				EmployeeDAO empde = Factory.getEmployeeDAOInstance();
				empde.operateemployee();
				break;
			case 4:
				HotelInformationDAO hotelinrd = Factory.getHotelInformationDAOInstance();
				hotelinrd.getAllhotels();

				break;
			case 5:
				EmployeeDAO employeeird = Factory.getEmployeeDAOInstance();
				employeeird.getAllemployees();
				break;
			case 6:
				BookingInformationDAO bookind = Factory.getBookingInformationDAOInstance();
				bookind.bookingspecifiedhotel();
				break;
			case 7:
				BookingInformationDAO bookind1 = Factory.getBookingInformationDAOInstance();
				bookind1.guestlistspecifiedhotel();

				break;
			case 8:
				BookingInformationDAO bookind12 = Factory.getBookingInformationDAOInstance();
				bookind12.bookingspecifieddate();
				break;
			case 9:
				break A;
			}

		} while (true);

		return true;
	}

}
