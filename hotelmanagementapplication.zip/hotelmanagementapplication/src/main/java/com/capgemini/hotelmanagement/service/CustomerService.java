package com.capgemini.hotelmanagement.service;

public interface CustomerService {
	
	public boolean Customer();

}
