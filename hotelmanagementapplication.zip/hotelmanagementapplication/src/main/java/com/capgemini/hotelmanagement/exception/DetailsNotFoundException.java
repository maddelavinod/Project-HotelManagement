package com.capgemini.hotelmanagement.exception;

@SuppressWarnings("serial")
public class DetailsNotFoundException extends RuntimeException {
	String message = "No Details present ";

	public String getExceptionMessage() {
		return message;

	}

}
