package com.capgemini.hotelmanagement.bean;

public class RoomInformationBean {

	private String roomnumber;

	private String hotelnum;

	private String roomtype;

	private String HotelName;

	private String hotellocation;

	private int price;

	public String getRoomnumber() {
		return roomnumber;
	}

	public void setRoomnumber(String roomnumber) {
		this.roomnumber = roomnumber;
	}

	public String getRoomtype() {
		return roomtype;
	}

	public void setRoomtype(String roomtype) {
		this.roomtype = roomtype;
	}

	public String getHotelname() {
		return HotelName;
	}

	public void setHotelname(String hotelname) {
		this.HotelName = hotelname;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getHotelnum() {
		return hotelnum;
	}

	public void setHotelnum(String hotelnum) {
		this.hotelnum = hotelnum;
	}

	public String getHotellocation() {
		return hotellocation;
	}

	public void setHotellocation(String hotellocation) {
		this.hotellocation = hotellocation;
	}

	@Override
	public String toString() {
		return "RoomInformationBean [roomnumber=" + roomnumber + ", hotelnum=" + hotelnum + ", roomtype=" + roomtype
				+ ", HotelName=" + HotelName + ", hotellocation=" + hotellocation + ", price=" + price + "]";
	}

}
