package com.capgemini.hotelmanagement.dao;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.HotelInformationBean;
import com.capgemini.hotelmanagement.bean.RoomInformationBean;
import com.capgemini.hotelmanagement.exception.DetailsNotFoundException;
import com.capgemini.hotelmanagement.exception.EmployeeNotFoundException;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class RoomInformationDAOImpl implements RoomInformationDAO {

	static final Logger log = Logger.getLogger(RoomInformationDAOImpl.class);
	Scanner sc = new Scanner(System.in);
	InputValidation inputvalidation = Factory.getInputValidationInstance();
	HotelInformationBean hotelinfo = Factory.getHotelInformationInstance();
	static List<RoomInformationBean> room = new ArrayList<RoomInformationBean>();
	int size = 0;
	int count = 0;

	static {

		RoomInformationBean roominfo = new RoomInformationBean();
		roominfo.setHotelnum("2");
		roominfo.setHotelname("Green View");
		roominfo.setRoomnumber("2011");
		roominfo.setRoomtype("Single");
		roominfo.setHotellocation("banglore");
		roominfo.setPrice(10000);

		RoomInformationBean roominfo2 = new RoomInformationBean();
		roominfo2.setHotelnum("2");
		roominfo2.setHotelname("Green View");
		roominfo2.setRoomnumber("202");
		roominfo2.setRoomtype("Double");
		roominfo2.setHotellocation("banglore");
		roominfo2.setPrice(20000);

		RoomInformationBean roominfo4 = new RoomInformationBean();
		roominfo4.setHotelnum("1");
		roominfo4.setHotelname("Royal Palace");
		roominfo4.setRoomnumber("1011");
		roominfo4.setRoomtype("Single");
		roominfo4.setHotellocation("banglore");
		roominfo4.setPrice(10000);

		RoomInformationBean roominfo6 = new RoomInformationBean();
		roominfo6.setHotelnum("1");
		roominfo6.setHotelname("Royal Palace");
		roominfo6.setRoomnumber("102");
		roominfo6.setRoomtype("Double");
		roominfo6.setHotellocation("banglore");
		roominfo6.setPrice(20000);

		RoomInformationBean roominfo8 = new RoomInformationBean();
		roominfo8.setHotelnum("2");
		roominfo8.setHotelname("Hotel Palasa");
		roominfo8.setRoomnumber("2011");
		roominfo8.setRoomtype("Single");
		roominfo8.setHotellocation("hyderabad");
		roominfo8.setPrice(10000);

		RoomInformationBean roominfo10 = new RoomInformationBean();
		roominfo10.setHotelnum("2");
		roominfo10.setHotelname("Hotel Palasa");
		roominfo10.setRoomnumber("202");
		roominfo10.setRoomtype("Double");
		roominfo10.setHotellocation("hyderabad");
		roominfo10.setPrice(20000);

		RoomInformationBean roominfo12 = new RoomInformationBean();
		roominfo12.setHotelnum("1");
		roominfo12.setHotelname("Grand Chola");
		roominfo12.setRoomnumber("1011");
		roominfo12.setRoomtype("Single");
		roominfo12.setHotellocation("hyderabad");
		roominfo12.setPrice(10000);

		RoomInformationBean roominfo14 = new RoomInformationBean();
		roominfo14.setHotelnum("1");
		roominfo14.setHotelname("Grand Chola");
		roominfo14.setRoomnumber("102");
		roominfo14.setRoomtype("Double");
		roominfo14.setHotellocation("hyderabad");
		roominfo14.setPrice(20000);

		room.add(roominfo);

		room.add(roominfo2);

		room.add(roominfo4);

		room.add(roominfo6);

		room.add(roominfo8);

		room.add(roominfo10);

		room.add(roominfo12);

		room.add(roominfo14);

	}

	@Override
	public boolean roomAvailability(String number, String location) {
		BookingInformationDAO bookinginfo = Factory.getBookingInformationDAOInstance();
		log.info("------------ Available rooms --------------");
		log.info("Room num " + "     " + " Room Type" + "     " + " Room price");
		for (RoomInformationBean roominfobean : room) {
			if (roominfobean.getHotelnum().equals(number) && roominfobean.getHotellocation().equals(location)) {

				log.info(roominfobean.getRoomnumber() + "     " + roominfobean.getRoomtype() + "     "
						+ roominfobean.getPrice());
			}
		}

		M: do {
			log.info("-----------Select Room Type Requried-------------");
			log.info("1.Single(Allows Two Members in Single Room)");
			log.info("2.Double(Aloows Four Members in Double Room)");
			log.info("3.back");

			String choice1 = sc.nextLine();
			while (!inputvalidation.choiceValidate2(choice1)) {
				log.info("Select valid choice");
				choice1 = sc.nextLine();

			}
			int choice = Integer.parseInt(choice1);
			switch (choice) {
			case 1:
				String roomtype = "Single";
				for (RoomInformationBean roominfo : room) {

					if (roominfo.getRoomtype().equals(roomtype) && roominfo.getHotellocation().equals(location)
							&& roominfo.getHotelnum().equals(number)) {
						bookinginfo.roombooking(roominfo);

					}

				}
				break;
			case 2:
				String roomtype1 = "Double";
				for (RoomInformationBean roominfo : room) {
					if (roominfo.getRoomtype().equals(roomtype1) && roominfo.getHotellocation().equals(location)
							&& roominfo.getHotelnum().equals(number)) {
						bookinginfo.roombooking(roominfo);

					}
				}
				break;
			case 3:
				break M;
			}

		} while (true);
		return true;
	}

	@Override
	public boolean operaterooms() {
		D: do {
			log.info("Please Select the operation of hotel");
			log.info("1.addrooms");
			log.info("2.delete rooms");
			log.info("3.update rooms");
			log.info("4.get All Rooms");
			log.info("5.back");
			String ant = sc.nextLine();
			while (!inputvalidation.choiceValidation5(ant)) {
				log.info("Please Enter valid choice");
				ant = sc.nextLine();
			}
			int vall = Integer.parseInt(ant);
			switch (vall) {
			case 1:
				RoomInformationBean roomin = Factory.getRoomInformationInstance();
				addrooms(roomin);

				break;
			case 2:
				deleteroom();

				break;
			case 3:
				RoomInformationBean roomin1 = Factory.getRoomInformationInstance();
				updateroom(roomin1);

				break;
			case 4:
				getAllRooms();
				break;
			case 5:
				break D;
			}
		} while (true);
		return true;
	}

	@Override
	public boolean addrooms(RoomInformationBean roomift) {

		RoomInformationBean roominxd = Factory.getRoomInformationInstance();
		ArrayList<RoomInformationBean> roomadd = new ArrayList<RoomInformationBean>();

		String roomtype1 = "Single";
		String roomtype2 = "Double";

		log.info("Enter hotel location");
		String hoteloc = sc.nextLine();
		log.info("Enter hotel name");
		String hotelnam = sc.nextLine();
		log.info("Enter hotel number");
		String hotelnum = sc.nextLine();

		K: for (RoomInformationBean roominf : room) {
			if (roominf.getHotellocation().equals(hoteloc) && roominf.getHotelname().equals(hotelnam)
					&& roominf.getHotelnum().equals(hotelnum)) {
				count++;
				log.info("Add your room details");

				log.info("Add room number");
				String roomnum = sc.nextLine();
				if (roominf.getHotelname().equals(hotelnam) && roominf.getRoomnumber().equals(roomnum)) {
					log.info("Room number exists enter new room number");
					roomnum = sc.nextLine();
				}
				while (!inputvalidation.roomnumberValidation(roomnum)) {
					log.info("Enter valid room number only numbers");
					roomnum = sc.nextLine();
				}

				log.info("Enter room type like 'Single'or'Double'");

				String roomtype = sc.nextLine();
				while (!(roomtype1.equals(roomtype) || roomtype2.equals(roomtype))) {
					log.info("Enter room type like 'Single'or'Double'");
					roomtype = sc.nextLine();

				}
				while (!inputvalidation.locationValidation(roomtype)) {
					log.info("Enter room type like 'Single'or'Double'");
					roomtype = sc.nextLine();

				}

				log.info("Please Enter romm price only numbers");
				String roompri = sc.nextLine();
				while (!inputvalidation.priceValidation(roompri)) {
					log.info("Enter romm price only numbers");
					roompri = sc.nextLine();

				}
				int roomprice = Integer.parseInt(roompri);
				roominxd.setHotellocation(hoteloc);
				roominxd.setHotelname(hotelnam);
				roominxd.setHotelnum(hotelnum);
				roominxd.setRoomnumber(roomnum);
				roominxd.setRoomtype(roomtype);
				roominxd.setPrice(roomprice);

				break K;

			}
		}
		roomadd.add(roominxd);
		room.addAll(roomadd);
		try {
			if (count == 0) {
				throw new DetailsNotFoundException();
			} else {
				log.info("Adding room details sucessfull");
			}
		} catch (DetailsNotFoundException d) {
			log.info(d.getExceptionMessage());
			return false;
		}
		return true;

	}

	@Override
	public boolean deleteroom() {
		log.info("Enter room number");
		String rnum1 = sc.nextLine();
		while (!inputvalidation.roomnumberValidation(rnum1)) {
			log.info("Enter Valid number");
			rnum1 = sc.nextLine();
		}

		log.info("Please Enter Hotel Name");
		String hotelna = sc.nextLine();
		while (!inputvalidation.nameValidation(hotelna)) {
			log.info("Please Enter valid hotel name");
			hotelna = sc.nextLine();
		}

		log.info("Please Enter Hotel Location");
		String hlocation = sc.nextLine();
		while (!inputvalidation.locationValidation(hlocation)) {
			log.info("Enter Valid location");
			hlocation = sc.nextLine();
		}
		Iterator<RoomInformationBean> roombean = room.iterator();
		while (roombean.hasNext()) {

			RoomInformationBean str = roombean.next();
			if (str.getRoomnumber().equals(rnum1) && str.getHotelname().equals(hotelna)
					&& str.getHotellocation().equals(hlocation)) {
				count++;

				log.info("Room found");
				roombean.remove();
				log.info("Data Deleted sucessfull");

			}

		}
		try {
			if (count == 0) {
				throw new DetailsNotFoundException();

			}
		} catch (DetailsNotFoundException d) {
			log.info(d.getExceptionMessage());
			return false;
		}

		return true;
	}

	@Override
	public boolean updateroom(RoomInformationBean roominof) {

		log.info("Enter room number");
		String rnum2 = sc.nextLine();
		while (!inputvalidation.roomnumberValidation(rnum2)) {
			log.info("Enter Valid number");
			rnum2 = sc.nextLine();
		}

		log.info("Please Enter Hotel Name");
		String hotelnam = sc.nextLine();
		while (!inputvalidation.nameValidation(hotelnam)) {
			log.info("Please Enter valid hotel name");
			hotelnam = sc.nextLine();
		}

		log.info("Please Enter Hotel Location");
		String hlocation1 = sc.nextLine();
		while (!inputvalidation.locationValidation(hlocation1)) {
			log.info("Enter Valid location");
			hlocation1 = sc.nextLine();
		}
		for (RoomInformationBean rooming : room) {
			if (rooming.getRoomnumber().equals(rnum2) && rooming.getHotelname().equals(hotelnam)
					&& rooming.getHotellocation().equals(hlocation1)) {

				count++;
				log.info("Request is Done ");
				log.info(" ============= update details ==============");

				log.info("Enter roomtype");
				String rtype = sc.nextLine();
				while (!inputvalidation.locationValidation(rtype)) {
					log.info("Please Enter Valid roomtype");
					rtype = sc.nextLine();
				}

				log.info("Enter price of room type");
				String rprice = sc.nextLine();
				while (!inputvalidation.priceValidation(rprice)) {
					log.info("enter valid price");
					rprice = sc.nextLine();
				}
				int rooprice = Integer.parseInt(rprice);

				rooming.setRoomnumber(rnum2);
				rooming.setHotellocation(hlocation1);
				rooming.setHotelname(hotelnam);
				rooming.setRoomtype(rtype);
				rooming.setPrice(rooprice);

				log.info("Data Updated sucessfully");
			}
		}
		try {
			if (count == 0) {
				throw new DetailsNotFoundException();
			}
		} catch (DetailsNotFoundException f) {
			log.info(f.getExceptionMessage());
			return false;
		}

		return true;
	}

	@Override
	public List<RoomInformationBean> getAllRooms() {
		log.info("*****Room Details***********");
		for (RoomInformationBean roominfds : room) {
			try {
				if (room.isEmpty()) {
					throw new EmployeeNotFoundException();
				} else {
					log.info(roominfds);
				}
			} catch (EmployeeNotFoundException z) {
				log.info(z.getExceptionMessage());
			}
		}
		return room;
	}

}
