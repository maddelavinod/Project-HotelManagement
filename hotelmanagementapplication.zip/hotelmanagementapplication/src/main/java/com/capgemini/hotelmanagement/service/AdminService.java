package com.capgemini.hotelmanagement.service;

import java.io.FileNotFoundException;

import java.io.IOException;

public interface AdminService {

	public boolean Hotel() throws FileNotFoundException, IOException;

}
