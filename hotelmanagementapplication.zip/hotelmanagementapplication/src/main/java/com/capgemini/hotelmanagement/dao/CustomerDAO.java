package com.capgemini.hotelmanagement.dao;

import java.util.List;

import com.capgemini.hotelmanagement.bean.CustomerInformationBean;

public interface CustomerDAO {

	public boolean customerlogin();

	public boolean customerregistration(CustomerInformationBean register);

	public boolean hotelbooking();

	public List<CustomerInformationBean> getAllCustomers();

	public boolean operatecustomer();
	
	public boolean updatecustomer();

}
