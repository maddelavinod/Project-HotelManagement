package com.capgemini.hotelmanagement.bean;

import java.time.LocalDate;

public class BookingInformationBean {

	private String bookingusername;

	private String bookingname;

	private Long bookingnumber;

	private String bookinghotel;

	private String bookingroomnum;

	private String bookingroomtype;

	private int bookingprice;

	private LocalDate bookingdate;

	private LocalDate chechindate;

	private LocalDate checkoutdate;

	public String getBookingname() {
		return bookingname;
	}

	public void setBookingname(String bookingname) {
		this.bookingname = bookingname;
	}

	public String getBookinghotel() {
		return bookinghotel;
	}

	public void setBookinghotel(String bookinghotel) {
		this.bookinghotel = bookinghotel;
	}

	public String getBookingroomnum() {
		return bookingroomnum;
	}

	public void setBookingroomnum(String i) {
		this.bookingroomnum = i;
	}

	public String getBookingroomtype() {
		return bookingroomtype;
	}

	public void setBookingroomtype(String bookingroomtype) {
		this.bookingroomtype = bookingroomtype;
	}

	public LocalDate getBookingdate() {
		return bookingdate;
	}

	public void setBookingdate(LocalDate bookingdate) {
		this.bookingdate = bookingdate;
	}

	public LocalDate getChechindate() {
		return chechindate;
	}

	public void setChechindate(LocalDate chechindate) {
		this.chechindate = chechindate;
	}

	public LocalDate getCheckoutdate() {
		return checkoutdate;
	}

	public void setCheckoutdate(LocalDate checkoutdate) {
		this.checkoutdate = checkoutdate;
	}

	public String getBookingusername() {
		return bookingusername;
	}

	public void setBookingusername(String bookingusername) {
		this.bookingusername = bookingusername;
	}

	public Long getBookingnumber() {
		return bookingnumber;
	}

	public void setBookingnumber(Long bookingnumber) {
		this.bookingnumber = bookingnumber;
	}

	public int getBookingprice() {
		return bookingprice;
	}

	public void setBookingprice(int bookingprice) {
		this.bookingprice = bookingprice;
	}

	@Override
	public String toString() {
		return "BookingInformationBean [bookingusername=" + bookingusername + ", bookingname=" + bookingname
				+ ", bookingnumber=" + bookingnumber + ", bookinghotel=" + bookinghotel + ", bookingroomnum="
				+ bookingroomnum + ", bookingroomtype=" + bookingroomtype + ", bookingprice=" + bookingprice
				+ ", bookingdate=" + bookingdate + ", chechindate=" + chechindate + ", checkoutdate=" + checkoutdate
				+ "]";
	}

}
