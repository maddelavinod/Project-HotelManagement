package com.capgemini.hotelmanagement.exception;

@SuppressWarnings("serial")
public class BookingDetailsNotFoundException extends RuntimeException {

	String message = "Booking is not done ";

	public String requriedmessage() {
		return message;

	}

}
