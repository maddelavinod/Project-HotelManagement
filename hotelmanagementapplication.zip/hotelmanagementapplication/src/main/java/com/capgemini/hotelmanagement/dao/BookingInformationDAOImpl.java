package com.capgemini.hotelmanagement.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.BookingInformationBean;
import com.capgemini.hotelmanagement.bean.CustomerInformationBean;
import com.capgemini.hotelmanagement.bean.RoomInformationBean;
import com.capgemini.hotelmanagement.exception.BookingDetailsNotFoundException;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class BookingInformationDAOImpl implements BookingInformationDAO {
	CustomerInformationBean cust = Factory.getCustomerInformationInstance();

	static final Logger log = Logger.getLogger(BookingInformationDAO.class);
	Scanner sc = new Scanner(System.in);
	InputValidation inputvalidation = Factory.getInputValidationInstance();
	static List<BookingInformationBean> booking = new ArrayList<BookingInformationBean>();
	CustomerDAO customer = Factory.getCustomerDAOInstance();
	int count = 0;
	static {
		BookingInformationBean bookinginr = Factory.getBookingInformationBeanInstance();
		bookinginr.setBookingname("vinod c");
		bookinginr.setBookingusername("vinod");
		bookinginr.setBookinghotel("Green View");
		bookinginr.setBookingnumber(9493115665l);
		bookinginr.setBookingroomtype("Single");
		bookinginr.setBookingroomnum("2011");
		bookinginr.setBookingprice(10000);
		bookinginr.setBookingdate(LocalDate.of(2020, 05, 06));
		bookinginr.setChechindate(LocalDate.of(2020, 05, 10));
		bookinginr.setCheckoutdate(LocalDate.of(2020, 05, 11));

		BookingInformationBean bookinginr1 = Factory.getBookingInformationBeanInstance();
		bookinginr1.setBookingname("chandra d");
		bookinginr1.setBookingusername("vinod1730");
		bookinginr1.setBookinghotel("Green View");
		bookinginr1.setBookingnumber(9493115663l);
		bookinginr1.setBookingroomtype("Double");
		bookinginr1.setBookingroomnum("202");
		bookinginr1.setBookingprice(20000);
		bookinginr1.setBookingdate(LocalDate.of(2020, 05, 10));
		bookinginr1.setChechindate(LocalDate.of(2020, 05, 10));
		bookinginr1.setCheckoutdate(LocalDate.of(2020, 05, 19));

		BookingInformationBean bookinginr2 = Factory.getBookingInformationBeanInstance();
		bookinginr2.setBookingname("maddela m");
		bookinginr2.setBookingusername("maddela5046");
		bookinginr2.setBookinghotel("Royal Palace");
		bookinginr2.setBookingnumber(9493112665l);
		bookinginr2.setBookingroomtype("Double");
		bookinginr2.setBookingroomnum("102");
		bookinginr2.setBookingprice(20000);
		bookinginr2.setBookingdate(LocalDate.of(2020, 05, 06));
		bookinginr2.setChechindate(LocalDate.of(2020, 05, 28));
		bookinginr2.setCheckoutdate(LocalDate.of(2020, 05, 29));

		BookingInformationBean bookinginr3 = Factory.getBookingInformationBeanInstance();
		bookinginr3.setBookingname("prathap m");
		bookinginr3.setBookingusername("maddela5046");
		bookinginr3.setBookinghotel("Royal Palace");
		bookinginr3.setBookingnumber(9493112665l);
		bookinginr3.setBookingroomtype("Single");
		bookinginr3.setBookingroomnum("1011");
		bookinginr3.setBookingprice(10000);
		bookinginr3.setBookingdate(LocalDate.of(2020, 05, 06));
		bookinginr3.setChechindate(LocalDate.of(2020, 05, 22));
		bookinginr3.setCheckoutdate(LocalDate.of(2020, 05, 29));

		booking.add(bookinginr);
		booking.add(bookinginr1);
		booking.add(bookinginr2);
		booking.add(bookinginr3);

	}

	@Override
	public boolean roombooking(RoomInformationBean roominfo) {
		BookingInformationBean bookinginfo = Factory.getBookingInformationBeanInstance();
		log.info("Please enter your name");
		String name = sc.nextLine();
		while (!inputvalidation.nameValidation(name)) {
			log.info("Name should be first name and last name");
			name = sc.nextLine();
		}

		log.info("Please enter your username ");
		String username = sc.nextLine();
		while (!inputvalidation.usernameValidation(username)) {
			log.info("Username can contains 3-14 characters");
			name = sc.nextLine();
		}

		log.info("please enter your number");
		String number1 = sc.nextLine();
		while (!inputvalidation.phonenumberValidation(number1)) {
			log.info("Please enter valid number");
			number1 = sc.nextLine();
		}
		long cont = Long.parseLong(number1);

		log.info("Enter chech-in date (yyyy-mm-dd))");
		String datein = sc.nextLine();
		while (!inputvalidation.dateValidation(datein)) {
			log.info("Please enter vaild date (yyyy-mm-dd)");
			datein = sc.nextLine();
		}
		LocalDate checkin = LocalDate.parse(datein);
		while (checkin.isBefore(LocalDate.now())) {
			log.info("Check-in date should be present date or future date");
			datein = sc.nextLine();
			while (!inputvalidation.dateValidation(datein)) {
				log.info("Enter valid date");
			}try {
				
				checkin = LocalDate.parse(datein);
			}catch(Exception  e) {
				log.info("Please Enter valid date");
				
			}

		}

		log.info("Enter check-out date (yyyy-mm-dd)");
		String dateout = sc.nextLine();
		while (!inputvalidation.dateValidation(dateout)) {
			log.info("Please enter vaild date(yyyy-mm-dd)");
			dateout = sc.nextLine();
		}
		LocalDate checkout = LocalDate.parse(dateout);
		while (checkout.isBefore(checkin)) {
			log.info("Check-out date should be check-in or future date");
			dateout = sc.nextLine();
			while (!inputvalidation.dateValidation(dateout)) {
				log.info("Enter valid date");
			}
			checkout = LocalDate.parse(dateout);
		}

		bookinginfo.setBookingusername(username);
		bookinginfo.setBookingname(name);
		bookinginfo.setBookingnumber(cont);
		bookinginfo.setBookingdate(LocalDate.now());
		bookinginfo.setBookinghotel(roominfo.getHotelname());
		bookinginfo.setBookingroomtype(roominfo.getRoomtype());
		bookinginfo.setBookingprice(roominfo.getPrice());
		bookinginfo.setBookingroomnum(roominfo.getRoomnumber());
		bookinginfo.setChechindate(checkin);
		bookinginfo.setCheckoutdate(checkout);

		booking.add(bookinginfo);

		log.info("Booing sucessfull");
		log.info(bookinginfo.toString());

		return true;

	}

	@Override
	public boolean bookingspecifiedhotel() {
		log.info("Please Enter Hotel Name");

		String honame = sc.nextLine();
		while (!inputvalidation.nameValidation(honame)) {
			log.info("Please enter valid hotel name");
			honame = sc.nextLine();

		}
		for (BookingInformationBean bookinginx : booking) {
			if (bookinginx.getBookinghotel().equals(honame)) {
				count++;
			}
		}
		try {
			if (count == 0) {
				throw new BookingDetailsNotFoundException();
			} else {
				log.info(count + ".Bookings in that hotel");
			}
		} catch (BookingDetailsNotFoundException z) {
			log.info(z.requriedmessage());
			return false;
		}

		return true;
	}

	@Override
	public boolean guestlistspecifiedhotel() {
		log.info("Please Enter Hotel Name");
		String honame = sc.nextLine();
		while (!inputvalidation.nameValidation(honame)) {
			log.info("Please enter valid hotel name");
			honame = sc.nextLine();

		}
		for (BookingInformationBean bookinginj : booking) {
			if (bookinginj.getBookinghotel().equals(honame)) {
				count++;
				log.info(bookinginj);
			}
		}
		try {
			if (count == 0) {
				throw new BookingDetailsNotFoundException();
			} else {
				log.info("Booking list at  hotel----" + honame);
			}
		} catch (BookingDetailsNotFoundException z) {
			log.info(z.requriedmessage());
			return false;
		}

		return true;
	}

	@Override
	public boolean bookingspecifieddate() {
		log.info("Enter The Date You Requried");
		String rdate = sc.nextLine();
		while (!inputvalidation.dateValidation(rdate)) {
			log.info("Enter valid date");
			rdate = sc.nextLine();
		}
		LocalDate datech = LocalDate.parse(rdate);
		for (BookingInformationBean bookinginjx : booking) {
			if (bookinginjx.getBookingdate().equals(datech)) {
				count++;
				log.info(bookinginjx);

			}

		}
		try {
			if (count == 0) {
				throw new BookingDetailsNotFoundException();
			} else {
				log.info("Booking list at  specified date");
			}
		} catch (BookingDetailsNotFoundException z) {
			log.info(z.requriedmessage());
			return false;
		}
		return true;
	}

	@Override
	public boolean getbooking() {
		log.info("Please Enter your username");
		String usern = sc.nextLine();
		for (BookingInformationBean bookingh : booking) {
			if (bookingh.getBookingusername().equals(usern)) {
				count++;
				log.info(bookingh);
			}
		}
		try {
			if (count == 0) {
				throw new BookingDetailsNotFoundException();
			} else {
				log.info("Booking list at  specified date");
			}
		} catch (BookingDetailsNotFoundException z) {
			log.info(z.requriedmessage());
			return false;
		}
		return true;
	}
}
