package com.capgemini.hotelmanagement.dao;

import com.capgemini.hotelmanagement.bean.RoomInformationBean;

public interface BookingInformationDAO {

	public boolean roombooking(RoomInformationBean roominfo);

	public boolean bookingspecifiedhotel();

	public boolean guestlistspecifiedhotel();

	public boolean bookingspecifieddate();

	public boolean getbooking();

}
