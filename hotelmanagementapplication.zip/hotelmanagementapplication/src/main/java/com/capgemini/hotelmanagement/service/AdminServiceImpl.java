package com.capgemini.hotelmanagement.service;

import java.io.IOException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.dao.AdminDAO;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class AdminServiceImpl implements AdminService {

	static final Logger log = Logger.getLogger(AdminServiceImpl.class);
	Scanner sc = new Scanner(System.in);
	InputValidation inputvalidation = Factory.getInputValidationInstance();

	@Override
	public boolean Hotel() throws IOException {

		L: do {
			log.info("Welcome to Admin Module");

			log.info("1.Admin Login");
			log.info("2.Exit");

			String access = sc.nextLine();
			while (!inputvalidation.choiceValidate3(access)) {
				log.info("Please Enter Valid Choice");
				access = sc.nextLine();
			}
			int choice = Integer.parseInt(access);
			switch (choice) {
			case 1:

				AdminDAO admindao = Factory.getAdminDAOInstance();
				admindao.AdminLogin();

				break;
			case 2:
				break L;
			}

		} while (true);
		return true;
	}

}
