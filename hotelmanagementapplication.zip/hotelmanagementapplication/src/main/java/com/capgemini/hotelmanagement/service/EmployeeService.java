package com.capgemini.hotelmanagement.service;

public interface EmployeeService {

	public boolean employee();

}
