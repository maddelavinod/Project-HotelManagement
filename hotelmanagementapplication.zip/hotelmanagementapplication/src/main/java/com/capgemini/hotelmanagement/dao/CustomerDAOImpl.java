package com.capgemini.hotelmanagement.dao;

import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelmanagement.bean.CustomerInformationBean;
import com.capgemini.hotelmanagement.exception.CustomerNotFoundException;
import com.capgemini.hotelmanagement.exception.RegistrationFailedException;
import com.capgemini.hotelmanagement.exception.UserNameNotFoundException;
import com.capgemini.hotelmanagement.factory.Factory;
import com.capgemini.hotelmanagement.validation.InputValidation;

public class CustomerDAOImpl implements CustomerDAO {

	static final Logger log = Logger.getLogger(CustomerDAOImpl.class);
	Scanner sc = new Scanner(System.in);
	InputValidation inputvalidation = Factory.getInputValidationInstance();
	static List<CustomerInformationBean> customer = new ArrayList<CustomerInformationBean>();
	InputValidation inputValidations = Factory.getInputValidationInstance();
	int count = 0;
	int size = 0;

	static {
		CustomerInformationBean customerregistration = Factory.getCustomerInformationInstance();
		customerregistration.setUserName("vinod");
		customerregistration.setName("vinod m");
		customerregistration.setMailId("vinod@gmail.com");
		customerregistration.setPhoneNumber(9493115665l);
		customerregistration.setPassword("Vinod@123");
		customer.add(customerregistration);

	}

	@Override
	public boolean customerregistration(CustomerInformationBean register) {
		CustomerInformationBean customerregistration = Factory.getCustomerInformationInstance();
		ArrayList<CustomerInformationBean> custo = new ArrayList<CustomerInformationBean>();

		log.info("Enter your username ");
		String UserName = sc.nextLine();
		for (CustomerInformationBean cnx : customer) {
			while (cnx.getUserName().equals(UserName)) {
				log.info("username already exists");
				log.info(
						"Enter your username (It can contains characters and numbers and special characters,but length must be 3-14)");
				UserName = sc.nextLine();
			}
		}

		while (!inputvalidation.usernameValidation(UserName)) {
			log.info(
					"Enter valid username (It can contains characters and numbers and special characters'-','_',but length must be 3-14)");
			UserName = sc.nextLine();
		}
		log.info("Enter your name like First-name and Last-name");
		String name = sc.nextLine();

		while (!inputvalidation.nameValidation(name)) {
			log.info("please enter valid name like first name and last name");
			name = sc.nextLine();
		}
		log.info("Enter your phone number must contains 10 digits and starts with 6 or 7 or 8 or 9");
		String phonenumber = sc.nextLine();

		while (!inputvalidation.phonenumberValidation(phonenumber)) {
			log.info("phone number must contains 10 digits and starts with 6 or 7 or 8 or 9");
			phonenumber = sc.nextLine();
		}

		long PhoneNumber = Long.parseLong(phonenumber);

		log.info("Enter your mail like abc@abc.abc");
		String mail = sc.nextLine();
		for (CustomerInformationBean cmxts : customer) {
			while (cmxts.getMailId().equals(mail)) {
				log.info("mailid is exists");
				log.info("Enter your mail abc@abc.abc");
				mail = sc.nextLine();
			}
		}
		while (!inputvalidation.mailValidation(mail)) {
			log.info("Please enter your valid mail id");
			mail = sc.nextLine();

		}
		log.info("Enter your password must contain one uppercase,one lower case,numbers and special characters");
		String password = sc.nextLine();
		while (!inputvalidation.passwordValidation(password)) {
			log.info("password must contain one uppercase,one lower case,numbers and special characters");
			password = sc.nextLine();
		}

		customerregistration.setUserName(UserName);
		customerregistration.setName(name);
		customerregistration.setPhoneNumber(PhoneNumber);
		customerregistration.setMailId(mail);
		customerregistration.setPassword(password);
		custo.add(customerregistration);
		customer.addAll(custo);
		try {
			if (size == customer.size()) {
				log.info("Registration is not sucessfull ");
				return false;
			} else {
				log.info("Registration is sucessfull");
			}
		} catch (RegistrationFailedException e) {
			log.error(e.getDetails());
		}
		return true;

	}

	@Override
	public boolean customerlogin() {

		log.info("Enter your user name");
		String username = sc.nextLine();
		log.info("Enter your password");
		String Password = sc.nextLine();

		int count = 0;
		for (CustomerInformationBean customers : customer) {
			if (customers.getUserName().equals(username) && customers.getPassword().equals(Password)) {
				count++;

			}
		}

		if (count == 1) {
			log.info("****Login Successsfull*****");
			operatecustomer();
			return true;
		} else {
			log.info("login details not found if you are a new customer please Register");
		}

		return false;
	}

	@Override
	public boolean hotelbooking() {
		HotelInformationDAO hotelinfo = Factory.getHotelInformationDAOInstance();

		K: do {
			log.info("Please select location ");
			log.info("1.hyderabad");
			log.info("2.banglore");
			log.info("3.back");
			String cccc = sc.nextLine();
			while (!inputvalidation.choiceValidate2(cccc)) {
				log.info("please enter valid choice ");
				cccc = sc.nextLine();
			}
			int optt = Integer.parseInt(cccc);
			switch (optt) {
			case 1:
				hotelinfo.GetHotel("hyderabad");

				break;
			case 2:
				hotelinfo.GetHotel("banglore");

				break;
			case 3:
				break K;
			}

		} while (true);
		return true;
	}

	@Override
	public List<CustomerInformationBean> getAllCustomers() {
		log.info("*****Get All Customers*****");
		for (CustomerInformationBean customerinfo : customer) {
			try {
				if (customer.isEmpty()) {
					throw new CustomerNotFoundException();
				} else {
					log.info(customerinfo);
				}
			} catch (CustomerNotFoundException e) {
				log.error(e.getMessage());
			}
		}

		return customer;

	}

	@Override
	public boolean operatecustomer() {
		CustomerDAOImpl customerimpl = (CustomerDAOImpl) Factory.getCustomerDAOInstance();
		K: do {
			log.info("Please select your operation");
			log.info("1.Booking Hotel");
			log.info("2.Booking Status");
			log.info("3.logout");
			String next = sc.nextLine();
			while (!inputvalidation.choiceValidate2(next)) {
				log.info("Enter valid choice");
				next = sc.nextLine();
			}
			int opt = Integer.parseInt(next);
			switch (opt) {
			case 1:
				customerimpl.hotelbooking();
				break;
			case 2:
				BookingInformationDAO bookingx = Factory.getBookingInformationDAOInstance();
				bookingx.getbooking();
				break;
			case 3:
				break K;

			}
		} while (true);
		return true;
	}

	@Override
	public boolean updatecustomer() {

		log.info("Enter your username");
		String usname = sc.nextLine();
		for (CustomerInformationBean cust : customer) {
			if (cust.getUserName().equals(usname)) {
				count++;
				log.info("Enter your new password contain one uppercase,one lower case,numbers and special characters");
				String passw = sc.nextLine();
				while (!inputvalidation.passwordValidation(passw)) {
					log.info(
							"Enter your new password contain one uppercase,one lower case,numbers and special characters");
					passw = sc.nextLine();

				}
				cust.setPassword(passw);

			}
		}
		try {
			if (count == 0) {
				throw new UserNameNotFoundException();

			} else {
				log.info("Password Updated");
			}
		} catch (UserNameNotFoundException e) {
			log.info(e.requriedmessage());
			return false;
		}
		return true;
	}

}
