package com.capgemini.hotelmanagement.validation;

public interface InputValidation {

	public boolean usernameValidation(String username);

	public boolean nameValidation(String name);

	public boolean phonenumberValidation(String Contactnumber);

	public boolean mailValidation(String mail);

	public boolean passwordValidation(String password);

	public boolean choiceValidate1(String choice);

	public boolean choiceValidate2(String choice);

	public boolean choiceValidate3(String choice);

	public boolean priceValidation(String price);

	public boolean dateValidation(String date);

	public boolean choiceValidation4(String choice);

	public boolean hotelnumberValidation(String hotelnumber);

	public boolean salaryValidation(String salary);

	public boolean locationValidation(String location);

	public boolean roomnumberValidation(String roomnumber);
	
	public boolean choiceValidation5(String choice);
	


}
