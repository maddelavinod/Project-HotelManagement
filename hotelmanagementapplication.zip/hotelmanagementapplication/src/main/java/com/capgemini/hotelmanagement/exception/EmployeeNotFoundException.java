package com.capgemini.hotelmanagement.exception;

@SuppressWarnings("serial")
public class EmployeeNotFoundException extends RuntimeException {
	String message = "No Details present ";

	public String getExceptionMessage() {
		return message;

	}

}
