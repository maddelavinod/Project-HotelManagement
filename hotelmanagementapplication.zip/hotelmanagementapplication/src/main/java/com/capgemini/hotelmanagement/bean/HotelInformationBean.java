package com.capgemini.hotelmanagement.bean;

public class HotelInformationBean {

	private String HotelNumber;

	private String HotelName;

	private String Location;

	private String Mailid;

	private long Phonenumber;

	public String getHotelNumber() {
		return HotelNumber;
	}

	public void setHotelNumber(String hotelNumber) {
		HotelNumber = hotelNumber;
	}

	public String getHotelName() {
		return HotelName;
	}

	public void setHotelName(String hotelName) {
		HotelName = hotelName;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

	public String getMailid() {
		return Mailid;
	}

	public void setMailid(String mailid) {
		Mailid = mailid;
	}

	public long getPhonenumber() {
		return Phonenumber;
	}

	public void setPhonenumber(long phonenumber) {
		Phonenumber = phonenumber;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((HotelName == null) ? 0 : HotelName.hashCode());
		result = prime * result + ((HotelNumber == null) ? 0 : HotelNumber.hashCode());
		result = prime * result + ((Location == null) ? 0 : Location.hashCode());
		result = prime * result + ((Mailid == null) ? 0 : Mailid.hashCode());
		result = prime * result + (int) (Phonenumber ^ (Phonenumber >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HotelInformationBean other = (HotelInformationBean) obj;
		if (HotelName == null) {
			if (other.HotelName != null)
				return false;
		} else if (!HotelName.equals(other.HotelName))
			return false;
		if (HotelNumber == null) {
			if (other.HotelNumber != null)
				return false;
		} else if (!HotelNumber.equals(other.HotelNumber))
			return false;
		if (Location == null) {
			if (other.Location != null)
				return false;
		} else if (!Location.equals(other.Location))
			return false;
		if (Mailid == null) {
			if (other.Mailid != null)
				return false;
		} else if (!Mailid.equals(other.Mailid))
			return false;
		if (Phonenumber != other.Phonenumber)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "HotelInformationBean [HotelNumber=" + HotelNumber + ", HotelName=" + HotelName + ", Location="
				+ Location + ", Mailid=" + Mailid + ", Phonenumber=" + Phonenumber + "]";
	}

}
