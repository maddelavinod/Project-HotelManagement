package com.capgemini.hotelmanagement.dao;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface AdminDAO {

	public boolean AdminLogin() throws FileNotFoundException, IOException;

	public boolean operateadmin();

}
