package com.capgemini.hotelmanagement.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputValidationImpl implements InputValidation {

	Pattern pat = null;
	Matcher mat = null;

	@Override
	public boolean usernameValidation(String username) {

		String regex = "^[0-a-z9_-]{3,14}$";

		pat = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		mat = pat.matcher(username);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean nameValidation(String name) {

		String regex = "[a-z][A-z]*+\\s[a-z][A-z]*+";

		pat = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		mat = pat.matcher(name);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean phonenumberValidation(String Contactnumber) {

		pat = Pattern.compile("^[6789]{1}\\d{9}$");
		mat = pat.matcher(Contactnumber);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean mailValidation(String mail) {

		pat = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
		mat = pat.matcher(mail);
		if (mat.matches()) {
			return true;
		}

		return false;
	}

	@Override
	public boolean passwordValidation(String password) {
		pat = Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})");
		mat = pat.matcher(password);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean choiceValidate1(String choice) {

		pat = Pattern.compile("[1-4]");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean choiceValidate2(String choice) {
		pat = Pattern.compile("[1-3]");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean choiceValidate3(String choice) {
		pat = Pattern.compile("[1-2]");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}

		return false;
	}

	@Override
	public boolean priceValidation(String price) {
		pat = Pattern.compile("\\d{4,5}");
		mat = pat.matcher(price);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean dateValidation(String date) {
		pat = Pattern.compile("[0-9]{4}-(0[1-9]|1[0-2])-(3[0-1]|[1-2][0-9]|0[0-9])");
		mat = pat.matcher(date);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean choiceValidation4(String choice) {
		pat = Pattern.compile("[1-9]");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}

		return false;
	}

	@Override
	public boolean hotelnumberValidation(String hotelnumber) {
		pat = Pattern.compile("\\d");
		mat = pat.matcher(hotelnumber);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean salaryValidation(String salary) {
		pat = Pattern.compile("\\d{5,6}");
		mat = pat.matcher(salary);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean locationValidation(String location) {
		String reg = "[a-z][A-z]*";
		pat = Pattern.compile(reg, Pattern.CASE_INSENSITIVE);
		mat = pat.matcher(location);
		if (mat.matches()) {
			return true;
		}

		return false;
	}

	@Override
	public boolean roomnumberValidation(String roomnumber) {
		pat = Pattern.compile("\\d{3,4}");
		mat = pat.matcher(roomnumber);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean choiceValidation5(String choice) {
		pat = Pattern.compile("[1-5]");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}

		return false;
	}

}
