package com.capgemini.hotelmanagement.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.bean.BookingInformationBean;
import com.capgemini.hotelmanagement.bean.RoomInformationBean;
import com.capgemini.hotelmanagement.factory.Factory;

class BookingInformationDAOImplTest {

	BookingInformationBean bookinginfo = Factory.getBookingInformationBeanInstance();
	BookingInformationDAO bookindao = Factory.getBookingInformationDAOInstance();
	RoomInformationBean roominfo = Factory.getRoomInformationInstance();

	@Test
	@DisplayName("Room Booking")
	void testRoombooking() {
		assertEquals(true, bookindao.roombooking(roominfo));
	}

	@Test
	@DisplayName("Booking Specified Date")
	void testBookingspecifieddate() {
		assertEquals(true, bookindao.bookingspecifieddate());
	}

	@Test
	@DisplayName("Get Booking")
	void testGetbooking() {
		assertEquals(true, bookindao.getbooking());
	}

	@Test
	@DisplayName("Invalid Booking Specified Date")
	void testBookingspecifieddate1() {
		assertEquals(false, bookindao.bookingspecifieddate());
	}
	
	@Test
	@DisplayName("Invalid Get Booking")
	void testGetbooking1() {
		assertEquals(false, bookindao.getbooking());
	}

}
