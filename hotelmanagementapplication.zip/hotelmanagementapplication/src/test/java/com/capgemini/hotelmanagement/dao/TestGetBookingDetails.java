package com.capgemini.hotelmanagement.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.factory.Factory;

public class TestGetBookingDetails {

	BookingInformationDAO bookingdao = Factory.getBookingInformationDAOInstance();

	@Test
	@DisplayName("Guest List Specified Hotel")
	void testGuestlistspecifiedhotel() {
		assertEquals(true, bookingdao.guestlistspecifiedhotel());
	}

	@Test
	@DisplayName("Booking Specified Hotel")
	void testBookingspecifiedhotel() {
		assertEquals(true, bookingdao.bookingspecifiedhotel());
	}

	@Test
	@DisplayName("In valid Guest List Specified Hotel")
	void testGuestlistspecifiedhotel1() {
		assertEquals(false, bookingdao.guestlistspecifiedhotel());
	}

	@Test
	@DisplayName("Invalid Booking Specified Hotel")
	void testBookingspecifiedhotel1() {
		assertEquals(false, bookingdao.bookingspecifiedhotel());
	}
}
