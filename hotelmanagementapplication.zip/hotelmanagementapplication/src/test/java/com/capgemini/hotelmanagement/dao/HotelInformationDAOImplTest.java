package com.capgemini.hotelmanagement.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.bean.HotelInformationBean;
import com.capgemini.hotelmanagement.factory.Factory;

class HotelInformationDAOImplTest {

	HotelInformationBean hotelinfo = Factory.getHotelInformationInstance();
	HotelInformationDAO hoteldao = Factory.getHotelInformationDAOInstance();

	@Test
	@DisplayName("Add Hotel")
	void testAddHotel() {
		assertEquals(true, hoteldao.AddHotel(hotelinfo));
	}

	@Test
	@DisplayName("Get  Hotels")
	void testGetHotel() {
		assertEquals(true, hoteldao.GetHotel("hyderabad"));
	}

	@Test
	@DisplayName("Get  Hotels two")
	void testGetHotel1() {
		assertEquals(true, hoteldao.GetHotel("banglore"));
	}

	@Test
	@DisplayName("Operate Hotel")
	void testOperatehotels() {
		assertEquals(true, hoteldao.operatehotels());
	}

	@Test
	@DisplayName("Delete Hotel")
	void testDeletehotel() {
		assertEquals(true, hoteldao.deletehotel());
	}

	@Test
	@DisplayName("Update Hotel")
	void testUpdatehotel() {
		assertEquals(true, hoteldao.updatehotel(hotelinfo));
	}

	@Test
	void testGetAllhotels() {
		assertNotNull(hoteldao.getAllhotels());
	}

	@Test
	@DisplayName("In valid Update Hotel")
	void testUpdatehotel1() {
		assertEquals(false, hoteldao.updatehotel(hotelinfo));
	}

	@Test
	@DisplayName("Invalid Delete Hotel")
	void testDeletehotel1() {
		assertEquals(false, hoteldao.deletehotel());
	}

}
