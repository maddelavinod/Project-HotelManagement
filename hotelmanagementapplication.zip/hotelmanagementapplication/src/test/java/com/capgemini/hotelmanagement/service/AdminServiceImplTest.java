package com.capgemini.hotelmanagement.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.factory.Factory;

class AdminServiceImplTest {

	AdminService adminservice = Factory.getAdminServiceInstance();
	

	@Test
	void testHotel() {

		try {
			assertEquals(true, adminservice.Hotel());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
