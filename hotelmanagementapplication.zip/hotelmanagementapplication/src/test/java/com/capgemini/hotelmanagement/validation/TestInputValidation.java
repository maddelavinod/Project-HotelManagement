package com.capgemini.hotelmanagement.validation;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.factory.Factory;

public class TestInputValidation {
	InputValidation input = Factory.getInputValidationInstance();

	@Test
	@DisplayName(" valid User name ")

	public void testUserNameValidation() {
		assertEquals(true, input.usernameValidation("vinod"));
	}

	@Test
	@DisplayName(" Invalid User name ")

	public void testUserNameValidation1() {
		assertEquals(false, input.usernameValidation("vi"));
	}

	@Test
	@DisplayName("Valid Name Validation ")

	public void testNameValidation() {
		assertEquals(true, input.nameValidation("Vinod Maddela"));
	}

	@Test
	@DisplayName("In Valid Name Validation ")

	public void testNameValidation1() {
		assertEquals(false, input.nameValidation("Vinod"));
	}

	@Test
	@DisplayName("Valid Phone Number")

	public void testPhoneNumberValidation() {
		assertEquals(true, input.phonenumberValidation("9493115665"));
	}

	@Test
	@DisplayName("In Valid Phone Number")

	public void testPhoneNumberValidation1() {
		assertEquals(false, input.phonenumberValidation("1493115665"));
	}

	@Test
	@DisplayName("valid mailid")

	public void testMailidValidation() {
		assertEquals(true, input.mailValidation("vinid@gmail.com"));
	}

	@Test
	@DisplayName("In valid mailid")

	public void testMailidValidation1() {
		assertEquals(false, input.mailValidation("vinidgmail.com"));
	}

	@Test
	@DisplayName("valid password")

	public void testPasswordValidation() {

		assertEquals(true, input.passwordValidation("Vinod@123"));
	}

	@Test
	@DisplayName("Invalid password")

	public void testPasswordValidation1() {

		assertEquals(false, input.passwordValidation("vinod@123"));
	}

	@Test
	@DisplayName("valid salary")

	public void testSalaryValidation() {
		assertEquals(true, input.salaryValidation("12000"));
	}

	@Test
	@DisplayName("Invalid salary")

	public void testSalaryValidation1() {
		assertEquals(false, input.salaryValidation("ad"));
	}

	@Test
	@DisplayName("valid price")

	public void testPriceValidation() {
		assertEquals(true, input.priceValidation("10000"));
	}

	@Test
	@DisplayName("Invalid price")

	public void testPriceValidation1() {
		assertEquals(false, input.priceValidation("1000000"));
	}

	@Test
	@DisplayName("valid date validation")

	public void testdate() {
		assertEquals(true, input.dateValidation("1997-09-24"));
	}

	@Test
	@DisplayName("Invalid date validation")

	public void testdate1() {
		assertEquals(false, input.dateValidation("24-09-1997"));
	}
	
	@Test
	@DisplayName("valid Hotel Location")
	
	public void testhotellocation() {
		
		assertEquals(true,input.locationValidation("bhi"));
	}
	
	@Test
	@DisplayName("Invalid Hotel Location")
	
	public void testhotellocation1() {
		
		assertEquals(false,input.locationValidation("123"));
	}
	
	@Test
	@DisplayName("valid Hotel number")
	
	public void testhotelnumber() {
		
		assertEquals(true,input.hotelnumberValidation("1"));
		
		
	}
	
	@Test
	@DisplayName("Invalid Hotel number")
	
	public void testhotelnumbe1r() {
		
		assertEquals(false,input.hotelnumberValidation("ab"));
		
		
	}
	@Test
	@DisplayName("valid Room Number")
	
	public void testroomnumber() {
		
		assertEquals(true,input.roomnumberValidation("121"));
	}
	
	@Test
	@DisplayName("Invalid Room Number")
	
	public void testroomnumber1() {
		
		assertEquals(false,input.roomnumberValidation("ab"));
	}
	
	

}
