package com.capgemini.hotelmanagement.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.factory.Factory;

class CustomerServiceImplTest {
	CustomerService customerinfoser = Factory.getCustomerServiceInstance();

	@Test
	void testCustomer() {
		assertEquals(true, customerinfoser.Customer());
	}

}
