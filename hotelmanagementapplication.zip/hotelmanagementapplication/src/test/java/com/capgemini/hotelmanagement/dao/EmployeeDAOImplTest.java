package com.capgemini.hotelmanagement.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.bean.EmployeeInformationBean;
import com.capgemini.hotelmanagement.factory.Factory;

class EmployeeDAOImplTest {

	EmployeeInformationBean employeeinfo = Factory.getEmployeeInformationBeanInstance();
	EmployeeDAO employeedao = Factory.getEmployeeDAOInstance();

	@Test
	@DisplayName("Employee Login")
	void testEmployeelogin() {
		assertEquals(true, employeedao.employeelogin());
	}

	@Test
	@DisplayName("Operate Employee")
	void testOperateemployee() {
		assertEquals(true, employeedao.operateemployee());
	}

	@Test
	@DisplayName("Add Employee")
	void testAddEmployee() {
		assertEquals(true, employeedao.AddEmployee(employeeinfo));
	}

	@Test
	@DisplayName("Delete Employee")
	void testDeleteemployee() {
		assertEquals(true, employeedao.deleteemployee());
	}

	@Test
	@DisplayName("Update Employee")
	void testUpdateemployee() {
		assertEquals(true, employeedao.updateemployee(employeeinfo));
	}

	@Test
	@DisplayName("Get All Employees")
	void testGetAllemployees() {
		assertNotNull(employeedao.getAllemployees());
	}

	@Test
	void testEmployee() {
		assertEquals(true, employeedao.employee());
	}
	
	@Test
	@DisplayName("Invalid Delete Employee")
	void testDeleteemployee1() {
		assertEquals(false, employeedao.deleteemployee());
	}
	
	@Test
	@DisplayName("Invalid Employee Login")
	void testEmployeelogin1() {
		assertEquals(false, employeedao.employeelogin());
	}
	
	@Test
	@DisplayName("Invalid Update Employee")
	void testUpdateemployee1() {
		assertEquals(false, employeedao.updateemployee(employeeinfo));
	}


}
