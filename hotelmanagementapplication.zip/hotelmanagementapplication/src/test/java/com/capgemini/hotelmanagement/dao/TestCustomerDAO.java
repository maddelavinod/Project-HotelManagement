package com.capgemini.hotelmanagement.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.bean.CustomerInformationBean;
import com.capgemini.hotelmanagement.factory.Factory;

public class TestCustomerDAO {
	CustomerInformationBean customerInfo = Factory.getCustomerInformationInstance();
	CustomerDAO customerDao = Factory.getCustomerDAOInstance();

	@Test
	@DisplayName("Registration")

	void testCustomerRegistration() {
		assertEquals(true, customerDao.customerregistration(customerInfo));
	}

	@Test
	@DisplayName("Valid Login")
	void testCustomerlogin() {
		assertEquals(true, customerDao.customerlogin());
	}

	@Test
	@DisplayName("Invalid Login")
	void testCustomerlogin1() {
		assertEquals(false, customerDao.customerlogin());
	}

	@Test
	@DisplayName("Invalid Update")
	void testUpdatecustomer() {
		assertEquals(false, customerDao.updatecustomer());
	}

	@Test
	@DisplayName("Valid Update")
	void testUpdatecustomer1() {
		assertEquals(true, customerDao.updatecustomer());
	}

	@Test
	@DisplayName("Get List Of Customers")
	void testGetCustomers() {
		assertNotNull(customerDao.getAllCustomers());
	}

	@Test
	@DisplayName("Hotel Booking")
	void testhotelbooking() {
		assertEquals(true, customerDao.hotelbooking());
	}
}
