package com.capgemini.hotelmanagement.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.bean.RoomInformationBean;
import com.capgemini.hotelmanagement.factory.Factory;

class RoomInformationDAOImplTest {

	RoomInformationBean roominfo = Factory.getRoomInformationInstance();
	RoomInformationDAO roomdao = Factory.getRoomInformationDAOInstance();

	@Test
	@DisplayName("Operate rooms")
	void testOperaterooms() {
		assertEquals(true, roomdao.operaterooms());
	}

	@Test
	@DisplayName("Add Rooms")
	void testAddrooms() {
		assertEquals(true, roomdao.addrooms(roominfo));
	}

	@Test
	@DisplayName("Delete Room")
	void testDeleteroom() {
		assertEquals(true, roomdao.deleteroom());
	}

	@Test
	@DisplayName("Update Room")
	void testUpdateroom() {
		assertEquals(true, roomdao.updateroom(roominfo));
	}

	@Test
	@DisplayName("Invalid Delete Room")
	void testDeleteroom1() {
		assertEquals(false, roomdao.deleteroom());
	}

	@Test
	@DisplayName("Invalid Update Room")
	void testUpdateroom1() {
		assertEquals(false, roomdao.updateroom(roominfo));
	}

}
