package com.capgemini.hotelmanagement.service;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagement.factory.Factory;

class EmployeeServiceImplTest {

	EmployeeService employeeser = Factory.getEmployeeServiceInstance();

	@Test
	void testEmployee() {
		assertEquals(true, employeeser.employee());
	}

}
